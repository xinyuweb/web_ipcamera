/*
 * webrom.c -- Compiled Web Pages
 *
 * Copyright (c) GoAhead Software Inc., 1995-2010. All Rights Reserved.
 *
 * See the file "license.txt" for usage and redistribution license requirements
 *
 */

#include "wsIntrn.h"

websRomPageIndexType websRomPageIndex[] = {
  { 0, 0, 0 },
};

