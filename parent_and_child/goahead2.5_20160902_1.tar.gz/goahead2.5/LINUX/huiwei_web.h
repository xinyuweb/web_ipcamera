#ifndef _huiwei_web_h
#define _huiwei_web_h








int huiwei_function_register(void);



#endif  /*_huiwei_web_h*/