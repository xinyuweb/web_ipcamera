#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <time.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <dirent.h>
#include <sys/statfs.h>

#include "common.h"
#include "huiwei_web.h"
#include	"../uemf.h"
#include	"../wsIntrn.h"


#undef  DBG_ON
#undef  FILE_NAME
#define 	DBG_ON  	(0x01)
#define 	FILE_NAME 	"huiwei_web:"



#define  HUIWEI_DEV_NAME 		"ip_camera"
#define  HUIWEI_SOFT_VER		"1.2.0"
#define  HUIWEI_FIRMWARE_VER	"1.1.0"
#define  HUIWEI_MAIN_DNS 		"8.8.8.8"
#define  HUWEI_SUB_DNS 			"8.8.4.4"
#define  HUIWEI_MMC_PATH		"/tmp/mmc_dir/"
#define  HUIWEI_MMC_OUT			"off"

//#define  HUIWEI_MMC_PATH		"/mnt/"


typedef struct dev_info
{
	char * device_name;
	char * soft_ver;
	char * firmware_ver;
	char net_name[6];
	char net_gateway[18];
	char main_dns[18];
	char sub_dns[18];
	char start_up_time[64];
	char ip_addres[18];
	char bcast_addres[18];
	char netmask_addres[18];
	char mac_addres[24];
	char user_counts;

	
}dev_info_t;



typedef struct huiwei_web 
{
	dev_info_t * dev_info_camera;	


}huiwei_web_t;



static huiwei_web_t * huiwei_web_handle = NULL;



static void * huiwei_web_new_handle(void)
{

	huiwei_web_t * new_handle = calloc(1,sizeof(*new_handle));
	if(NULL == new_handle)
	{
		dbg_printf("calloc is fail!\n");
		return(NULL);

	}
	return(new_handle);
}

static int huiwei_web_free_handle(void)
{

	huiwei_web_t * handle = huiwei_web_handle;
	if(NULL == handle)
	{
		dbg_printf("the handle has been inited!\n");
		return(-1);
	}

	if(NULL != handle->dev_info_camera)
	{
		free(handle->dev_info_camera);
		handle->dev_info_camera = NULL;
	}

	free(handle);
	handle = NULL;
	


}



static int web_get_localtime(char * out,int length)
{

	char * week_day[] = {"Sun","Mon","Tue","Wed","Thu","Fri","Sat"};
	struct tm *time_tm = NULL; 
	time_t time_data;
	time(&time_data);

	time_tm=localtime(&time_data);
	#if 0
	snprintf(out,length,"%d\\%d\\%d %s %d:%d:%d",(1900+time_tm->tm_year),( 1+time_tm->tm_mon),\
		time_tm->tm_mday,week_day[time_tm->tm_wday],time_tm->tm_hour, time_tm->tm_min, time_tm->tm_sec);
	#else
		snprintf(&out[0],length,"%d-%d-%d",(1900+time_tm->tm_year),( 1+time_tm->tm_mon),time_tm->tm_mday);
		snprintf(&out[31],length,"%d:%d:%d",time_tm->tm_hour, time_tm->tm_min, time_tm->tm_sec);
	#endif
	
	dbg_printf("the start up time is: %s\n",out);
	return(0);
}



static int web_get_curtime(char * out,int length)
{

	char * week_day[] = {"Sun","Mon","Tue","Wed","Thu","Fri","Sat"};
	struct tm *time_tm = NULL; 
	time_t time_data;
	time(&time_data);

	time_tm=localtime(&time_data);
	snprintf(out,length,"%d:%d:%d:%d:%d:%d",(1900+time_tm->tm_year),( 1+time_tm->tm_mon),time_tm->tm_mday,time_tm->tm_hour, time_tm->tm_min, time_tm->tm_sec);
	//dbg_printf("the start up time is: %s\n",out);
	return(0);
}


static int web_get_gateway(char * out,int length)
{
	if(NULL == out || 0==length)
	{
		dbg_printf("check the param!\n");
		return(-1);
	}

	int ret = -1;
	FILE * fp_cmd = NULL;
	char cmd[128] = {'\0'};
	char buff[1024] ={'\0'};
	strcpy(cmd,"iproute");
	fp_cmd = popen(cmd,"r");
	if(NULL == fp_cmd)
	{
		dbg_printf("popen is fail!\n");
		return(-1);
	}

	ret = fread(buff,1,1024,fp_cmd);
	if(ret <= 0)
	{
		dbg_printf("fread is fail!\n");
		goto out;
	}

	char * p = strstr(buff,"default");
	if(NULL == p)
	{
		dbg_printf("find fail!\n");
		goto out;

	}

	sscanf(p,"%*s%*s%s",out);
	dbg_printf("the gate way is: %s\n",out);
	


	pclose(fp_cmd);
	fp_cmd = NULL;
	

	return(0);

out:

	pclose(fp_cmd);
	fp_cmd = NULL;
	return(-1);		

	
}



static int web_get_sdstatus(char * out,int length)
{
	if(NULL == out || 0==length)
	{
		dbg_printf("check the param!\n");
		return(-1);
	}

	int ret = -1;
	FILE * fp_cmd = NULL;
	char cmd[128] = {'\0'};
	char buff[1024] ={'\0'};
	strcpy(cmd,"df -h  | grep \"mmc\"");
	fp_cmd = popen(cmd,"r");
	if(NULL == fp_cmd)
	{
		dbg_printf("popen is fail!\n");
		return(-1);
	}

	ret = fread(buff,1,1024,fp_cmd);
	if(ret <= 0)
	{
		dbg_printf("mmc is out!\n");
		strcpy(out,HUIWEI_MMC_OUT);
		goto out;
	}
	
	char buff0[16]={'\0'};
	char buff1[16]={'\0'};
	char buff2[16]={'\0'};
	ret = sscanf(buff,"%*s%*[^0-9]%s%*[^0-9]%s%*[^0-9]%s",buff0,buff1,buff2);
	dbg_printf("mmc is: %s  %s  %s\n",buff0,buff1,buff2);
	snprintf(out,length,"%s / %s ",buff1,buff0);
	dbg_printf("%s \n",out);

	pclose(fp_cmd);
	fp_cmd = NULL;
	
	return(0);

out:

	pclose(fp_cmd);
	fp_cmd = NULL;
	return(-1);		

	
}

static void * web_get_devinfo(void)
{
	dev_info_t new_info;
	int i = 0;
	int ret = -1;
	int socket_fd = -1;

	memset(&new_info,'\0',sizeof(dev_info_t));
	for(i=0;i<16;++i)
	{

		memset(&new_info,'\0',sizeof(dev_info_t));
		socket_fd = socket(AF_INET,SOCK_DGRAM,0);
		if(socket_fd < 0)
		{
			dbg_printf("socket is fail!\n");
			break;
		}

		struct ifreq ifr;
		ifr.ifr_ifindex=i+1;
		ret=ioctl(socket_fd,SIOCGIFNAME,&ifr);
		if(0 != ret)
		{
			dbg_printf("get it fail!\n");
			close(socket_fd);
			socket_fd = -1;

			break;
		}

		
		ret = strncmp(ifr.ifr_name,"lo",2);
		if(0 ==ret)
		{
			close(socket_fd);
			socket_fd = -1;
			continue;

		}
		ret = ioctl(socket_fd, SIOCGIFFLAGS, &ifr);
		if(ret != 0)
		{
			dbg_printf("SIOCGIFFLAGS is fail!\n");
			close(socket_fd);
			socket_fd = -1;
			continue;

		}
		ret = ((ifr.ifr_flags & IFF_UP) && (ifr.ifr_flags & IFF_RUNNING));
		if(0 == ret)
		{
			dbg_printf("the net is not running!\n");
			close(socket_fd);
			socket_fd = -1;
			continue;

		}
		memmove(new_info.net_name,ifr.ifr_name,strlen(ifr.ifr_name));
		dbg_printf("the interface is:%s\n",ifr.ifr_name);

		ret =ioctl(socket_fd,SIOCGIFHWADDR,&ifr);
		if(0 != ret)
		{
			dbg_printf("SIOCGIFHWADDR is fail!\n");
			close(socket_fd);
			socket_fd = -1;
			continue;
		}
		
		unsigned char* mac_addr=ifr.ifr_hwaddr.sa_data;
		snprintf(new_info.mac_addres,24,"%02x:%02x:%02x:%02x:%02x:%02x",mac_addr[0],mac_addr[1],mac_addr[2],mac_addr[3],mac_addr[4],mac_addr[5]);
		dbg_printf("the mac addres is: %s\n",new_info.mac_addres);


		ret = ioctl(socket_fd,SIOCGIFADDR,&ifr);
		if(0 != ret)
		{
			dbg_printf("SIOCGIFADDR is fail!\n");
			close(socket_fd);
			socket_fd = -1;
			continue;	
		}
		struct sockaddr_in *sin=(struct sockaddr_in*)&ifr.ifr_addr;
		inet_ntop(AF_INET,&sin->sin_addr.s_addr,new_info.ip_addres,16);
		dbg_printf("the ip addres is: %s\n",new_info.ip_addres);


		ret = ioctl(socket_fd,SIOCGIFBRDADDR,&ifr);
		if(0 != ret)
		{
			dbg_printf("SIOCGIFBRDADDR is fail!\n");
			close(socket_fd);
			socket_fd = -1;
			continue;	

		}

		
		struct sockaddr_in *broadcast=(struct sockaddr_in*)&ifr.ifr_broadaddr;
		inet_ntop(AF_INET,&broadcast->sin_addr.s_addr,new_info.bcast_addres,16);
		dbg_printf("the bcast addres is: %s\n",new_info.bcast_addres);


		ret = ioctl(socket_fd,SIOCGIFNETMASK,&ifr);
		if(0 != ret)
		{
			dbg_printf("SIOCGIFNETMASK is fail!\n");
			close(socket_fd);
			socket_fd = -1;
			continue;		
		}

		
		struct sockaddr_in *netmask =(struct sockaddr_in*)&ifr.ifr_addr;
		inet_ntop(AF_INET,&netmask->sin_addr.s_addr,new_info.netmask_addres,16);
		dbg_printf("new_info.netmask_addres: %s\n",new_info.netmask_addres);


		close(socket_fd);
		socket_fd = -1;
		break;

	}



	new_info.device_name = HUIWEI_DEV_NAME;
	new_info.soft_ver = HUIWEI_SOFT_VER;
	new_info.firmware_ver = HUIWEI_FIRMWARE_VER;
	web_get_gateway(new_info.net_gateway,sizeof(new_info.net_gateway)/sizeof(new_info.net_gateway[0]));
	strncpy(new_info.main_dns,HUIWEI_MAIN_DNS,strlen(HUIWEI_MAIN_DNS));
	strncpy(new_info.sub_dns,HUWEI_SUB_DNS,strlen(HUWEI_SUB_DNS));
	web_get_localtime(new_info.start_up_time,sizeof(new_info.start_up_time)/sizeof(new_info.start_up_time[0]));
	new_info.user_counts = 1;  
	dev_info_t  * new_node = calloc(1,sizeof(*new_node));
	if(NULL == new_node)
	{
		dbg_printf("calloc is fail!\n");
		return(NULL);
	}

	*new_node = new_info;
	return(new_node);

}


//web_get_sdstatus(new_info.sd_status,128);

static int asp_device_name(int eid, webs_t wp, int argc, char_t **argv)
{

	if(NULL==huiwei_web_handle || NULL==huiwei_web_handle->dev_info_camera)
	{
		dbg_printf("check the param!\n");
		return(-1);

	}
	dev_info_t * dev_info_handle = huiwei_web_handle->dev_info_camera;
	websWrite(wp, T("%s"),dev_info_handle->device_name);
	
	return(0);	
}


static int asp_soft_ver(int eid, webs_t wp, int argc, char_t **argv)
{

	if(NULL==huiwei_web_handle || NULL==huiwei_web_handle->dev_info_camera)
	{
		dbg_printf("check the param!\n");
		return(-1);

	}
	dev_info_t * dev_info_handle = huiwei_web_handle->dev_info_camera;
	websWrite(wp, T("%s"),dev_info_handle->soft_ver);
	
	return(0);	
}




static int asp_firmware_ver(int eid, webs_t wp, int argc, char_t **argv)
{

	if(NULL==huiwei_web_handle || NULL==huiwei_web_handle->dev_info_camera)
	{
		dbg_printf("check the param!\n");
		return(-1);

	}
	dev_info_t * dev_info_handle = huiwei_web_handle->dev_info_camera;
	websWrite(wp, T("%s"),dev_info_handle->firmware_ver);
	
	return(0);	
}



static int asp_net_name(int eid, webs_t wp, int argc, char_t **argv)
{

	if(NULL==huiwei_web_handle || NULL==huiwei_web_handle->dev_info_camera)
	{
		dbg_printf("check the param!\n");
		return(-1);

	}
	dev_info_t * dev_info_handle = huiwei_web_handle->dev_info_camera;
	websWrite(wp, T("%s"),dev_info_handle->net_name);
	
	return(0);	
}



static int asp_net_gateway(int eid, webs_t wp, int argc, char_t **argv)
{

	if(NULL==huiwei_web_handle || NULL==huiwei_web_handle->dev_info_camera)
	{
		dbg_printf("check the param!\n");
		return(-1);

	}
	dev_info_t * dev_info_handle = huiwei_web_handle->dev_info_camera;
	websWrite(wp, T("%s"),dev_info_handle->net_gateway);
	
	return(0);	
}



static int asp_main_dns(int eid, webs_t wp, int argc, char_t **argv)
{

	if(NULL==huiwei_web_handle || NULL==huiwei_web_handle->dev_info_camera)
	{
		dbg_printf("check the param!\n");
		return(-1);

	}
	dev_info_t * dev_info_handle = huiwei_web_handle->dev_info_camera;
	websWrite(wp, T("%s"),dev_info_handle->main_dns);
	
	return(0);	
}


static int asp_sub_dns(int eid, webs_t wp, int argc, char_t **argv)
{

	if(NULL==huiwei_web_handle || NULL==huiwei_web_handle->dev_info_camera)
	{
		dbg_printf("check the param!\n");
		return(-1);

	}
	dev_info_t * dev_info_handle = huiwei_web_handle->dev_info_camera;
	websWrite(wp, T("%s"),dev_info_handle->sub_dns);
	
	return(0);	
}



static int asp_start_up_time(int eid, webs_t wp, int argc, char_t **argv)
{

	if(NULL==huiwei_web_handle || NULL==huiwei_web_handle->dev_info_camera)
	{
		dbg_printf("check the param!\n");
		return(-1);

	}
	dev_info_t * dev_info_handle = huiwei_web_handle->dev_info_camera;
	websWrite(wp, T("%s %s"),&dev_info_handle->start_up_time[0],&dev_info_handle->start_up_time[31]);
	
	return(0);	
}


static int asp_ip_addres(int eid, webs_t wp, int argc, char_t **argv)
{

	if(NULL==huiwei_web_handle || NULL==huiwei_web_handle->dev_info_camera)
	{
		dbg_printf("check the param!\n");
		return(-1);

	}
	dev_info_t * dev_info_handle = huiwei_web_handle->dev_info_camera;
	websWrite(wp, T("%s"),dev_info_handle->ip_addres);
	
	return(0);	
}


static int asp_bcast_addres(int eid, webs_t wp, int argc, char_t **argv)
{

	if(NULL==huiwei_web_handle || NULL==huiwei_web_handle->dev_info_camera)
	{
		dbg_printf("check the param!\n");
		return(-1);

	}
	dev_info_t * dev_info_handle = huiwei_web_handle->dev_info_camera;
	websWrite(wp, T("%s"),dev_info_handle->bcast_addres);
	
	return(0);	
}



static int asp_netmask_addres(int eid, webs_t wp, int argc, char_t **argv)
{

	if(NULL==huiwei_web_handle || NULL==huiwei_web_handle->dev_info_camera)
	{
		dbg_printf("check the param!\n");
		return(-1);

	}
	dev_info_t * dev_info_handle = huiwei_web_handle->dev_info_camera;
	websWrite(wp, T("%s"),dev_info_handle->netmask_addres);
	
	return(0);	
}


static int asp_mac_addres(int eid, webs_t wp, int argc, char_t **argv)
{

	if(NULL==huiwei_web_handle || NULL==huiwei_web_handle->dev_info_camera)
	{
		dbg_printf("check the param!\n");
		return(-1);

	}
	dev_info_t * dev_info_handle = huiwei_web_handle->dev_info_camera;
	websWrite(wp, T("%s"),dev_info_handle->mac_addres);
	
	return(0);	
}


static int asp_user_counts(int eid, webs_t wp, int argc, char_t **argv)
{

	if(NULL==huiwei_web_handle || NULL==huiwei_web_handle->dev_info_camera)
	{
		dbg_printf("check the param!\n");
		return(-1);

	}
	dev_info_t * dev_info_handle = huiwei_web_handle->dev_info_camera;
	char buff[8] = {'\0'};
	snprintf(buff,8,"%d",dev_info_handle->user_counts);
	
	websWrite(wp, T("%s"),buff);
	
	return(0);	
}

static int asp_sd_status(int eid, webs_t wp, int argc, char_t **argv)
{

	char buff_data[128]={'\0'};
	web_get_sdstatus(buff_data,128);
	websWrite(wp, T("%s"),buff_data);
	return(0);	
}



static int asp_get_curret_time(int eid, webs_t wp, int argc, char_t **argv)
{

	char buff_data[128]={'\0'};
	web_get_curtime(buff_data,128);
	//websWrite(wp, T("%s   %s"),&buff_data[0],&buff_data[31]);
	websWrite(wp, T("%s"),buff_data);
	return(0);	
}


static void form_get_pc_time(webs_t wp, char_t *path, char_t *query)
{

	char * str_time = websGetVar(wp, T("stime"), NULL);
	if(NULL == str_time)
	{
		dbg_printf("the pc time is null!\n");
		return;
	}
	char cmd[128] = {'\0'};
	snprintf(cmd,128,"date -s \"%s\" ",str_time);
//	system(cmd);

	
}




static int aspTest2(int eid, webs_t wp, int argc, char_t **argv)
{
	char_t	*name, *address;

	if (ejArgs(argc, argv, T("%s %s"), &name, &address) < 2) {
		websError(wp, 400, T("Insufficient args\n"));
		return -1;
	}
	return websWrite(wp, T("Name12: %s, Address12 %s"), name, address);
}






int huiwei_web_init(void)
{

	if(NULL != huiwei_web_handle)
	{
		dbg_printf("the handle has been inited!\n");
		return(-1);

	}

	huiwei_web_handle = (huiwei_web_t*)huiwei_web_new_handle();
	if(NULL == huiwei_web_handle)
	{
		dbg_printf("huiwei_web_new_handle is fail!\n");
		return(-1);

	}

	huiwei_web_handle->dev_info_camera = (dev_info_t*)web_get_devinfo();
	if(NULL == huiwei_web_handle->dev_info_camera)
	{
		dbg_printf("web_get_devinfo is fail!\n");
		return(-1);
	}

	return(0);
}


int huiwei_function_register(void)
{

	int ret = -1;
	ret = huiwei_web_init();
	if(0 != ret)
	{
		dbg_printf("huiwei_web_init is fail!\n");
		return(-1);
	}
	
	websAspDefine(T("aspTest2"), aspTest2);
	websAspDefine(T("asp_device_name"), asp_device_name);
	websAspDefine(T("asp_soft_ver"), asp_soft_ver);
	websAspDefine(T("asp_firmware_ver"), asp_firmware_ver);
	websAspDefine(T("asp_net_name"), asp_net_name);
	websAspDefine(T("asp_net_gateway"), asp_net_gateway);
	websAspDefine(T("asp_main_dns"), asp_main_dns);
	websAspDefine(T("asp_sub_dns"), asp_sub_dns);
	websAspDefine(T("asp_start_up_time"), asp_start_up_time);
	websAspDefine(T("asp_ip_addres"), asp_ip_addres);
	websAspDefine(T("asp_bcast_addres"), asp_bcast_addres);
	websAspDefine(T("asp_mac_addres"), asp_mac_addres);
	websAspDefine(T("asp_user_counts"), asp_user_counts);
	websAspDefine(T("asp_sd_status"), asp_sd_status);
	websAspDefine(T("asp_netmask_addres"), asp_netmask_addres);
	websAspDefine(T("asp_get_curret_time"), asp_get_curret_time);

	
	websFormDefine(T("form_get_pc_time"), form_get_pc_time);

	
	return(0);
}







